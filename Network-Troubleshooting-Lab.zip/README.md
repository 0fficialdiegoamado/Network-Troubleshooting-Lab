# CCNA-style Network Troubleshooting Lab

Four FRRouting routers in a partial mesh plus two Linux hosts, wired with
[containerlab](https://containerlab.dev). OSPF (single area 0) on all
router-to-router links, /30 point-to-point subnets, loopbacks used as
router-ids. Baseline: **h1 can ping h2** and **every router sees all four
loopbacks**.

Injection scripts break one realistic thing at a time; a verifier tells you
when you've actually fixed it; the answers live in `solutions/`.

---

## Topology

```
            10.1.12.0/30                 10.1.23.0/30
   h1 ------ R1 ================ R2 ================ R3 ------.
 .1.10   .1 |  .1            .2 | .1              .2 | .2      |
192.168.1.0 |                   |                   |         | 10.1.34.0/30
        /24 |   10.1.13.0/30    |                   |         |
            '-------------------)----- eth2 --------'         | .1
                          .1        (R1) .2                   |
                                                          .2  |
                                             R4 ==============' 
                                          .1 |  eth1
                                192.168.4.0/24|
                                        .1    |
                                              h2  .10
```

| Link            | Subnet         | R-side          | peer            |
|-----------------|----------------|-----------------|-----------------|
| R1 eth1 – R2 eth1 | 10.1.12.0/30 | R1 .1 / R2 .2    | OSPF area 0     |
| R2 eth2 – R3 eth1 | 10.1.23.0/30 | R2 .1 / R3 .2    | OSPF area 0     |
| R3 eth2 – R4 eth1 | 10.1.34.0/30 | R3 .1 / R4 .2    | OSPF area 0     |
| R1 eth2 – R3 eth3 | 10.1.13.0/30 | R1 .1 / R3 .2    | OSPF area 0     |
| R1 eth3 – h1 eth1 | 192.168.1.0/24 | R1 .1 / h1 .10  | h1 gw = .1      |
| R4 eth2 – h2 eth1 | 192.168.4.0/24 | R4 .1 / h2 .10  | h2 gw = .1      |

Loopbacks / router-ids: `R1 10.0.0.1`, `R2 10.0.0.2`, `R3 10.0.0.3`,
`R4 10.0.0.4`. R1–R4 has no direct link (partial mesh); R4 is reachable only
through R3.

Files:

```
guide.html          visual walkthrough — open in a browser (topology map + all
                    8 scenarios + a "Run demo" auto-play)
clab.yml            topology
configs/            per-router startup config (bind-mounted read-only as
                    /etc/frr/frr.conf) + shared daemons / vtysh.conf
scripts/deploy.sh   bring the lab up
scripts/destroy.sh  tear it down
scripts/verify.sh   PASS/FAIL the baseline conditions
scripts/break.sh    inject fault <1-8> (silent about what it did)
scripts/fix.sh      restore baseline (fault-agnostic, idempotent)
solutions/<n>.md    the answer for scenario <n>
```

---

## Setup

### Requirements

- **Docker** (a Linux Docker host). containerlab does the veth/netns wiring
  itself, so it must run on Linux.
- **On macOS**: [colima](https://github.com/abiosoft/colima) provides the
  Linux VM. `brew install colima docker`, then the scripts drive containerlab
  *inside* the VM automatically.
- **containerlab**. Installed automatically in the VM by `scripts/deploy.sh`
  on first run, or `bash -c "$(curl -sL https://get.containerlab.dev)"`.

Router image: `quay.io/frrouting/frr:10.4.5`. Host image: `alpine:latest`.
Both are pulled on first deploy.

> Note: the old `frrouting/frr:latest` on Docker Hub (v8.4) segfaults on
> recent kernels — this lab pins the quay.io 10.4 image.

### Deploy

```bash
cd ccna-lab
./scripts/deploy.sh          # starts colima if needed, deploys the lab
```

Wait ~30 s for OSPF to converge, then:

```bash
./scripts/verify.sh
```

You want `BASELINE OK` (10/10 checks). If you just deployed and see a couple
of FAILs, wait another 20 s and re-run — OSPF is still converging.

### Destroy

```bash
./scripts/destroy.sh
```

On macOS you can also stop the whole VM afterwards with `colima stop`.

---

## Attaching to a device

Containers are named `clab-ccna-tshoot-<node>` (`R1`..`R4`, `h1`, `h2`).

Routers — drop into the FRR CLI (Cisco-like):

```bash
docker exec -it clab-ccna-tshoot-R1 vtysh

R1# show ip route
R1# show ip ospf neighbor
R1# show ip ospf interface eth1
R1# show running-config
R1# configure terminal
R1(config)# ...
```

One-off command without an interactive session:

```bash
docker exec clab-ccna-tshoot-R1 vtysh -c "show ip route ospf"
```

Shell on a router (FRR image is Alpine — `ip`, `ping`, `tc`, `iptables`):

```bash
docker exec -it clab-ccna-tshoot-R3 sh
```

Hosts:

```bash
docker exec -it clab-ccna-tshoot-h1 sh
/ # ip addr
/ # ip route
/ # ping 192.168.4.10
/ # traceroute 192.168.4.10
```

containerlab also writes an SSH config, so `ssh clab-ccna-tshoot-R1` works
from the Docker host (on macOS, from inside `colima ssh`).

---

## Running a scenario

```bash
# 1. Make sure you're starting clean
./scripts/verify.sh                # -> BASELINE OK

# 2. Inject a fault (1-8). It won't tell you what it changed.
./scripts/break.sh 3

# 3. Wait ~30s, then confirm it's broken and start troubleshooting
./scripts/verify.sh                # -> BASELINE BROKEN, with failing checks

#    Investigate with vtysh: show ip route / show ip ospf neighbor /
#    show ip ospf interface / show running-config / traceroute from h1 ...

# 4. Apply your fix by hand in vtysh. Re-run the verifier until it's green:
./scripts/verify.sh

# 5. Stuck, or want to check your reasoning?
cat solutions/3.md

# 6. Reset to baseline (any time, whatever state the lab is in)
./scripts/fix.sh
```

`break.sh` restores baseline before injecting, so scenarios are independent
and order doesn't matter. `fix.sh` is fault-agnostic: it reloads every
router from `configs/`, clears OSPF state, flushes router packet filters,
and resets host addressing.

### The eight faults

| # | Fault                              | Layer            |
|---|------------------------------------|------------------|
| 1 | Wrong subnet mask (R1 LAN /29)     | L3 addressing    |
| 2 | Missing OSPF `network` statement   | OSPF advertisement |
| 3 | Mismatched OSPF area on a link     | OSPF             |
| 4 | Shut-down interface                | L1/L2 admin      |
| 5 | Wrong static route                 | static vs OSPF   |
| 6 | Duplicate OSPF router-id           | OSPF             |
| 7 | ACL dropping ICMP                  | L3/L4 filtering  |
| 8 | Wrong default gateway on a host    | host config      |

Symptoms overlap on purpose (several faults isolate R4) — the exercise is
finding the *root cause* with the right show command, not guessing from the
symptom.

---

## Troubleshooting the lab itself

- **`verify.sh` says the lab isn't running** — `./scripts/deploy.sh`.
- **Deploy fails with "Link not found"** — a container crashed during
  wiring; `./scripts/destroy.sh` then deploy again.
- **`docker: command not found` / cannot connect** — `colima start`.
- **Checks flap right after deploy/fix** — OSPF dead interval is 40 s; give
  it 30–40 s and re-run.
