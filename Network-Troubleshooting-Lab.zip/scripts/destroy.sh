#!/usr/bin/env bash
# destroy.sh - tear the lab down.

set -eu
cd "$(dirname "$0")/.."
TOPO="clab.yml"

if command -v containerlab >/dev/null 2>&1 && [ "$(uname -s)" = "Linux" ]; then
    exec sudo containerlab destroy -t "$TOPO" --cleanup
fi

if command -v colima >/dev/null 2>&1; then
    LAB_PATH="$(pwd)"
    exec colima ssh -- bash -lc "cd '$LAB_PATH' && sudo containerlab destroy -t '$TOPO' --cleanup"
fi

echo "ERROR: need either containerlab (Linux) or colima (macOS)." >&2
exit 1
