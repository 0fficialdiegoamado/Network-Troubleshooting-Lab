# Shared helpers for the CCNA troubleshooting lab scripts.
# Sourced by verify.sh / break.sh / fix.sh — not meant to be run directly.

LAB_NAME="ccna-tshoot"
PREFIX="clab-${LAB_NAME}"
ROUTERS="R1 R2 R3 R4"
HOSTS="h1 h2"

# Resolve repo root regardless of where the script is called from.
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG_DIR="${REPO_ROOT}/configs"

if ! command -v docker >/dev/null 2>&1; then
    echo "ERROR: 'docker' not found in PATH." >&2
    echo "On macOS start the runtime first:  colima start" >&2
    exit 1
fi

# node <name> -> full container name
cname() { echo "${PREFIX}-$1"; }

# dexec <node> <cmd...>  : run a command inside a node
dexec() { local n="$1"; shift; docker exec "$(cname "$n")" "$@"; }

# vt <node> <vtysh-arg...> : run vtysh command(s) on a router
vt() {
    local n="$1"; shift
    local args=()
    local c
    for c in "$@"; do args+=(-c "$c"); done
    docker exec "$(cname "$n")" vtysh "${args[@]}"
}

# ensure the lab is actually running
require_lab() {
    if ! docker ps --format '{{.Names}}' | grep -q "^${PREFIX}-R1$"; then
        echo "ERROR: lab '${LAB_NAME}' is not running. Deploy it first:" >&2
        echo "  scripts/deploy.sh" >&2
        exit 1
    fi
}
