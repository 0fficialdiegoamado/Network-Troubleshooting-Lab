#!/usr/bin/env bash
# deploy.sh - bring the lab up.
#
# containerlab needs a Linux host for veth/netns wiring. On macOS this means
# running it inside the colima VM; on Linux it runs directly. This wrapper
# handles both.
#
# containerlab is pinned to 0.59.0: newer releases (0.6x-0.7x) add a veth
# "ownership altname" step that fails on colima/vz kernels ("Link not found").

set -eu
cd "$(dirname "$0")/.."
TOPO="clab.yml"
CLAB_VERSION="0.59.0"

install_clab_remote='
    need=0
    command -v containerlab >/dev/null 2>&1 || need=1
    [ "$need" = 0 ] && [ "$(containerlab version 2>/dev/null | awk "/version:/{print \$2}")" != "'"$CLAB_VERSION"'" ] && need=1
    if [ "$need" = 1 ]; then
        arch=$(dpkg --print-architecture 2>/dev/null || echo arm64)
        curl -sL -o /tmp/clab.deb "https://github.com/srl-labs/containerlab/releases/download/v'"$CLAB_VERSION"'/containerlab_'"$CLAB_VERSION"'_linux_${arch}.deb"
        sudo dpkg -i --force-downgrade /tmp/clab.deb
    fi
'

if command -v containerlab >/dev/null 2>&1 && [ "$(uname -s)" = "Linux" ]; then
    exec sudo containerlab deploy -t "$TOPO"
fi

if command -v colima >/dev/null 2>&1; then
    if ! colima status >/dev/null 2>&1; then
        echo "Starting colima..."
        colima start --cpu 4 --memory 5 --disk 20
    fi
    LAB_PATH="$(pwd)"
    echo "Deploying via colima VM ($LAB_PATH)..."
    exec colima ssh -- bash -lc "
        $install_clab_remote
        cd '$LAB_PATH' && sudo containerlab deploy -t '$TOPO'
    "
fi

echo "ERROR: need either containerlab (Linux) or colima (macOS - 'brew install colima docker')." >&2
exit 1
