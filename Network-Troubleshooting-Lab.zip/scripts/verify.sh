#!/usr/bin/env bash
# verify.sh - test the baseline conditions of the lab and print PASS/FAIL per check.
# Exit code 0 => every check passed (lab is at baseline).
# Exit code 1 => at least one check failed (a fault is present, or convergence
#                is still in progress - wait ~30s after any change and re-run).

set -u
cd "$(dirname "$0")"
# shellcheck source=lib.sh
source ./lib.sh
require_lab

PASS=0
FAIL=0
RED=$'\e[31m'; GREEN=$'\e[32m'; RESET=$'\e[0m'
[ -t 1 ] || { RED=""; GREEN=""; RESET=""; }

report() { # <status> <text>
    if [ "$1" = "PASS" ]; then
        printf '  [%sPASS%s] %s\n' "$GREEN" "$RESET" "$2"; PASS=$((PASS+1))
    else
        printf '  [%sFAIL%s] %s\n' "$RED" "$RESET" "$2"; FAIL=$((FAIL+1))
    fi
}

# ping helper: <node> <target-ip> ; returns 0 on any reply
ping_ok() { dexec "$1" ping -c 3 -W 1 "$2" >/dev/null 2>&1; }

LOOPBACKS="10.0.0.1 10.0.0.2 10.0.0.3 10.0.0.4"

# expected number of Full OSPF neighbors per router (bash 3.2 - no assoc arrays)
expect_nbr() {
    case "$1" in
        R1) echo 2 ;; R2) echo 2 ;; R3) echo 3 ;; R4) echo 1 ;;
    esac
}

echo
echo "=== End-to-end data plane ==="
if ping_ok h1 192.168.4.10; then report PASS "h1 -> h2  (192.168.4.10)"; else report FAIL "h1 -> h2  (192.168.4.10)"; fi
if ping_ok h2 192.168.1.10; then report PASS "h2 -> h1  (192.168.1.10)"; else report FAIL "h2 -> h1  (192.168.1.10)"; fi

echo
echo "=== Every router has all four loopbacks in 'show ip route' ==="
for r in $ROUTERS; do
    rt="$(vt "$r" 'show ip route' 2>/dev/null)"
    missing=""
    for lb in $LOOPBACKS; do
        echo "$rt" | grep -qE "(^|[[:space:]])${lb}/32" || missing="${missing} ${lb}"
    done
    if [ -z "$missing" ]; then report PASS "$r sees 10.0.0.1-4/32"
    else report FAIL "$r missing loopback(s):${missing}"; fi
done

echo
echo "=== OSPF adjacencies (Full) ==="
for r in $ROUTERS; do
    n="$(vt "$r" 'show ip ospf neighbor' 2>/dev/null | grep -c 'Full')"
    exp="$(expect_nbr "$r")"
    if [ "$n" = "$exp" ]; then report PASS "$r has $exp Full neighbor(s)"
    else report FAIL "$r has $n Full neighbor(s), expected $exp"; fi
done

echo
echo "-------------------------------------------"
printf 'Result: %d passed, %d failed\n' "$PASS" "$FAIL"
if [ "$FAIL" -eq 0 ]; then
    echo "${GREEN}BASELINE OK${RESET}"
    exit 0
else
    echo "${RED}BASELINE BROKEN${RESET}  (or OSPF still converging - wait and re-run)"
    exit 1
fi
