#!/usr/bin/env bash
# break.sh <1-8> - inject one fault into the running lab.
#
# This script is deliberately silent about what it changes. Your job is to
# find it with show commands and pings. If you want the answer, read
# solutions/<n>.md.
#
# Each run first restores baseline, then injects exactly one fault, so
# scenarios are independent.

set -u
cd "$(dirname "$0")"
# shellcheck source=lib.sh
source ./lib.sh
require_lab

N="${1:-}"
case "$N" in
    [1-8]) ;;
    *) echo "usage: $0 <1-8>" >&2; exit 2 ;;
esac

# --- clean slate -----------------------------------------------------------
./fix.sh >/dev/null 2>&1
sleep 20

# --- inject (all output suppressed on purpose) ----------------------------
{
case "$N" in
1)
    vt R1 'configure terminal' 'interface eth3' \
        'no ip address 192.168.1.1/24' 'ip address 192.168.1.1/29'
    ;;
2)
    vt R4 'configure terminal' 'router ospf' \
        'no network 192.168.4.0/24 area 0'
    ;;
3)
    vt R3 'configure terminal' 'router ospf' \
        'no network 10.1.34.0/30 area 0' 'network 10.1.34.0/30 area 1'
    vt R3 'clear ip ospf process'
    ;;
4)
    vt R1 'configure terminal' 'interface eth3' 'shutdown'
    ;;
5)
    vt R3 'configure terminal' 'ip route 192.168.4.0/24 10.1.13.1'
    ;;
6)
    vt R4 'configure terminal' 'router ospf' 'ospf router-id 10.0.0.3'
    vt R4 'clear ip ospf process'
    ;;
7)
    dexec R4 sh -c 'command -v iptables >/dev/null 2>&1 || apk add --no-cache iptables >/dev/null 2>&1
                    iptables -A FORWARD -p icmp -j DROP'
    ;;
8)
    dexec h1 ip route replace default via 192.168.1.254 dev eth1
    ;;
esac
} >/dev/null 2>&1

echo "Scenario ${N} injected."
echo "Give OSPF ~30s to react, then diagnose with:  scripts/verify.sh"
