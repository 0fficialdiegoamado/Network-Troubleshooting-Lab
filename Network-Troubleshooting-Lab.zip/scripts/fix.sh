#!/usr/bin/env bash
# fix.sh - restore the lab to baseline, regardless of which fault was injected.
#
# It is intentionally fault-agnostic and idempotent: it reloads every router
# from its pristine startup config, clears transient OSPF state, removes any
# packet filters, and resets host addressing. Safe to run any time.

set -u
cd "$(dirname "$0")"
# shellcheck source=lib.sh
source ./lib.sh
require_lab

echo "Restoring baseline..."

# 1. Reload each router from its pristine /etc/frr/frr.conf (bind-mounted from
#    configs/). This reverts config drift: subnet masks, OSPF network/area
#    statements, static routes, router-ids, admin-down interfaces, etc.
for r in $ROUTERS; do
    printf '  %s: reload frr.conf ... ' "$r"
    if dexec "$r" python3 /usr/lib/frr/frr-reload.py --reload --stdout /etc/frr/frr.conf >/dev/null 2>&1; then
        echo "ok"
    else
        echo "reload reported changes/errors (continuing)"
    fi
done

# 2. Force interfaces admin-up (belt and suspenders for the shutdown scenario).
for r in $ROUTERS; do
    for i in eth1 eth2 eth3; do
        dexec "$r" ip link set "$i" up 2>/dev/null || true
    done
done

# 3. Clear OSPF process everywhere (settles duplicate-router-id and any stuck
#    adjacencies after the reload).
for r in $ROUTERS; do
    vt "$r" 'clear ip ospf process' >/dev/null 2>&1 || true
done

# 4. Remove any packet filters left on the routers (ACL / iptables scenario).
for r in $ROUTERS; do
    dexec "$r" sh -c 'command -v iptables >/dev/null 2>&1 && { iptables -F FORWARD; iptables -F INPUT; iptables -F OUTPUT; } || true' 2>/dev/null || true
    dexec "$r" sh -c 'tc qdisc del dev eth1 root 2>/dev/null; tc qdisc del dev eth2 root 2>/dev/null; tc qdisc del dev eth3 root 2>/dev/null' 2>/dev/null || true
done

# 5. Reset host addressing and default gateways (wrong-default-gateway scenario).
dexec h1 sh -c 'ip addr flush dev eth1;
                ip addr add 192.168.1.10/24 dev eth1;
                ip route replace default via 192.168.1.1 dev eth1' 2>/dev/null || true
dexec h2 sh -c 'ip addr flush dev eth1;
                ip addr add 192.168.4.10/24 dev eth1;
                ip route replace default via 192.168.4.1 dev eth1' 2>/dev/null || true

echo
echo "Done. OSPF needs ~20-30s to reconverge - then run: scripts/verify.sh"
